#include <stdio.h>

int main(){
    int numero, dobro;
    scanf("%d", &numero);
    dobro = numero * 2;
    printf("dobro: %d", dobro);
    return 0;
    
}